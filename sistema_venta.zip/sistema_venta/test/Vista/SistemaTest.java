/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package Vista;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author ash_v
 */
public class SistemaTest {
    
    public SistemaTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of ListarCliente method, of class Sistema.
     */
    @Test
    public void testListarCliente() {
        System.out.println("ListarCliente");
        Sistema instance = new Sistema();
        instance.ListarCliente();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of ListarProveedor method, of class Sistema.
     */
    @Test
    public void testListarProveedor() {
        System.out.println("ListarProveedor");
        Sistema instance = new Sistema();
        instance.ListarProveedor();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of ListarUsuarios method, of class Sistema.
     */
    @Test
    public void testListarUsuarios() {
        System.out.println("ListarUsuarios");
        Sistema instance = new Sistema();
        instance.ListarUsuarios();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of ListarProductos method, of class Sistema.
     */
    @Test
    public void testListarProductos() {
        System.out.println("ListarProductos");
        Sistema instance = new Sistema();
        instance.ListarProductos();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of ListarConfig method, of class Sistema.
     */
    @Test
    public void testListarConfig() {
        System.out.println("ListarConfig");
        Sistema instance = new Sistema();
        instance.ListarConfig();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of ListarVentas method, of class Sistema.
     */
    @Test
    public void testListarVentas() {
        System.out.println("ListarVentas");
        Sistema instance = new Sistema();
        instance.ListarVentas();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of LimpiarTable method, of class Sistema.
     */
    @Test
    public void testLimpiarTable() {
        System.out.println("LimpiarTable");
        Sistema instance = new Sistema();
        instance.LimpiarTable();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of main method, of class Sistema.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        Sistema.main(args);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
